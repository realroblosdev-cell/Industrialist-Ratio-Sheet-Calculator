import json
import math
import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import traceback

if getattr(sys, "frozen", False):
    base_path = sys._MEIPASS
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

DICT_PATH = os.path.join(base_path, "Dictionary.json")

class RatioCalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ratio Creator")
        self.root.geometry("700x800")

        self.machines_data = {}
        self.item_recipes = {} 
        self.all_items = []

        self.load_data()

        # --- GUI ---
        self.route_var = tk.StringVar(value="balanced")
        
        lbl_route = ttk.Label(root, text="Select Route Strategy:", font=('Arial', 10, 'bold'))
        lbl_route.pack(pady=(10, 5))
        
        frame_routes = ttk.Frame(root)
        frame_routes.pack()
        
        ttk.Radiobutton(frame_routes, text="Cheapest Route (Lowest total cost)", variable=self.route_var, value="balanced").pack(anchor=tk.W)
        ttk.Radiobutton(frame_routes, text="Normal (Fewer Machines)", variable=self.route_var, value="normal").pack(anchor=tk.W)
        ttk.Radiobutton(frame_routes, text="Expensive (Least Machines)", variable=self.route_var, value="expensive").pack(anchor=tk.W)

        lbl_rate = ttk.Label(root, text="Desired Rate (items/s):", font=('Arial', 10, 'bold'))
        lbl_rate.pack(pady=(15, 5))
        self.entry_rate = ttk.Entry(root)
        self.entry_rate.pack()

        lbl_item = ttk.Label(root, text="Select Item:", font=('Arial', 10, 'bold'))
        lbl_item.pack(pady=(15, 5))

        self.search_var = tk.StringVar()
        self.search_var.trace("w", self.update_listbox)
        self.entry_search = ttk.Entry(root, textvariable=self.search_var)
        self.entry_search.pack(pady=(0, 5))

        self.listbox_items = tk.Listbox(root, height=6)
        self.listbox_items.pack(pady=5, fill=tk.X, padx=20)
        self.listbox_items.bind("<<ListboxSelect>>", self.on_item_select)
        
        self.selected_item = None

        btn_calc = ttk.Button(root, text="CALCULATE", command=self.calculate_ratio)
        btn_calc.pack(pady=15)

        self.text_output = tk.Text(root, height=25, width=85)
        self.text_output.pack(padx=10, pady=10)

        self.update_listbox()

    def load_data(self):
        file_path = DICT_PATH
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
                self.machines_data = data.get('machines', {})
                for m_key, m_val in self.machines_data.items():
                    for recipe in m_val.get('recipes', []):
                        for output in recipe.get('outputs', []):
                            item_name = output['item']
                            if item_name not in self.all_items: 
                                self.all_items.append(item_name)
                            if item_name not in self.item_recipes: 
                                self.item_recipes[item_name] = []
                            
                            recipe_ctx = recipe.copy()
                            recipe_ctx['_machine_name'] = m_val.get('name', m_key)
                            recipe_ctx['_machine_cost'] = m_val.get('cost', 0)
                            recipe_ctx['_machine_pollution'] = m_val.get('pollution_per_h', 0)
                            recipe_ctx['_power_per_s'] = recipe.get('power_input_mf_per_s', 0)
                            recipe_ctx['_machine_key'] = m_key
                            self.item_recipes[item_name].append(recipe_ctx)
                self.all_items.sort()
        except Exception as e:
            messagebox.showerror("Error", f"Could not load JSON: {e}")

    def update_listbox(self, *args):
        search_term = self.search_var.get().lower()
        self.listbox_items.delete(0, tk.END)
        for item in self.all_items:
            if item.lower().startswith(search_term):
                self.listbox_items.insert(tk.END, item)

    def on_item_select(self, event):
        selection = self.listbox_items.curselection()
        if selection: 
            self.selected_item = self.listbox_items.get(selection[0])

    def get_recipe_score(self, recipe, target_item, target_rate, visited, current_path, depth=0):
        """Calculate score for a specific recipe"""
        # Skip if we're too deep (avoid infinite complexity)
        if depth > 10:
            return float('inf'), float('inf'), float('inf'), float('inf')
        
        # Get output quantity
        out_qty = next(o['quantity'] for o in recipe['outputs'] if o['item'] == target_item)
        m_exact = target_rate / (out_qty / recipe['duration_s'])
        m_count = math.ceil(m_exact)
        
        # Base stats
        base_cost = m_count * recipe['_machine_cost']
        base_machines = m_count
        base_power = m_count * recipe['_power_per_s']
        base_pollution = m_count * recipe['_machine_pollution']
        
        # For extractors (no inputs), return immediately
        if not recipe.get('inputs'):
            return base_cost, base_machines, base_power, base_pollution
        
        # Track inputs
        input_stats = []
        total_input_cost = 0
        total_input_machines = 0
        total_input_power = 0
        total_input_pollution = 0
        
        for inp in recipe['inputs']:
            i_rate = m_exact * (inp['quantity'] / recipe['duration_s'])
            input_item = inp['item']
            
            # Skip if already in path (cycle)
            if input_item in current_path:
                return float('inf'), float('inf'), float('inf'), float('inf')
            
            # Find best recipe for this input
            input_recipes = self.item_recipes.get(input_item, [])
            if not input_recipes:
                return float('inf'), float('inf'), float('inf'), float('inf')
            
            best_input_cost = float('inf')
            best_input_machines = float('inf')
            best_input_power = 0
            best_input_pollution = 0
            
            for input_recipe in input_recipes:
                # Try this input recipe
                new_path = current_path.copy()
                new_path.add(target_item)
                c, m, p, pol = self.get_recipe_score(input_recipe, input_item, i_rate, visited, new_path, depth + 1)
                
                if c < best_input_cost:
                    best_input_cost = c
                    best_input_machines = m
                    best_input_power = p
                    best_input_pollution = pol
            
            if best_input_cost == float('inf'):
                return float('inf'), float('inf'), float('inf'), float('inf')
            
            total_input_cost += best_input_cost
            total_input_machines += best_input_machines
            total_input_power += best_input_power
            total_input_pollution += best_input_pollution
        
        return (base_cost + total_input_cost, 
                base_machines + total_input_machines,
                base_power + total_input_power,
                base_pollution + total_input_pollution)

    def find_best_recipe(self, item_name, rate, visited, current_path):
        """Find the best recipe for producing an item"""
        cache_key = (item_name, round(rate, 6))
        if cache_key in visited:
            return visited[cache_key]
        
        recipes = self.item_recipes.get(item_name, [])
        if not recipes:
            visited[cache_key] = None
            return None
        
        best_recipe = None
        best_stats = None
        strategy = self.route_var.get()
        
        for recipe in recipes:
            stats = self.get_recipe_score(recipe, item_name, rate, visited, current_path.copy())
            
            if stats[0] == float('inf'):
                continue  # Skip invalid recipes
            
            if best_recipe is None:
                best_recipe = recipe
                best_stats = stats
            else:
                if strategy == "expensive":
                    # For expensive: FEWEST total machines
                    if stats[1] < best_stats[1]:
                        best_recipe = recipe
                        best_stats = stats
                elif strategy == "balanced":
                    # For balanced: LOWEST total cost
                    if stats[0] < best_stats[0]:
                        best_recipe = recipe
                        best_stats = stats
                else:  # normal
                    # For normal: Fewest machines at THIS level (not total chain)
                    if stats[1] < best_stats[1]:
                        best_recipe = recipe
                        best_stats = stats
        
        visited[cache_key] = (best_recipe, best_stats)
        return visited[cache_key]

    def build_production_chain(self, item_name, rate, chain, visited, current_path):
        """Build the actual production chain"""
        if item_name in current_path:
            return
        
        current_path.add(item_name)
        
        result = self.find_best_recipe(item_name, rate, visited, current_path)
        if not result or not result[0]:
            current_path.remove(item_name)
            return
        
        recipe, stats = result
        
        # Get output quantity
        out_qty = next(o['quantity'] for o in recipe['outputs'] if o['item'] == item_name)
        m_exact = rate / (out_qty / recipe['duration_s'])
        m_count = math.ceil(m_exact)
        
        # Add this step to chain
        step = {
            "machine_name": recipe['_machine_name'],
            "count": m_count,
            "cost": m_count * recipe['_machine_cost'],
            "pollution": m_count * recipe['_machine_pollution'],
            "power": m_count * recipe['_power_per_s'],
            "inputs": [],
            "output_item": item_name,
            "output_rate": rate
        }
        
        # Process inputs
        for inp in recipe.get('inputs', []):
            i_rate = m_exact * (inp['quantity'] / recipe['duration_s'])
            step["inputs"].append({"item": inp['item'], "rate": i_rate})
            
            # Recursively build chain for inputs
            self.build_production_chain(inp['item'], i_rate, chain, visited, current_path.copy())
        
        # Only add if not already in chain (same machine producing same item)
        existing = next((s for s in chain if s["machine_name"] == step["machine_name"] and s["output_item"] == step["output_item"]), None)
        if existing:
            existing["count"] += step["count"]
            existing["cost"] += step["cost"]
            existing["pollution"] += step["pollution"]
            existing["power"] += step["power"]
            existing["output_rate"] += step["output_rate"]
            # Merge inputs
            for inp in step["inputs"]:
                existing_inp = next((i for i in existing["inputs"] if i["item"] == inp["item"]), None)
                if existing_inp:
                    existing_inp["rate"] += inp["rate"]
                else:
                    existing["inputs"].append(inp)
        else:
            chain.append(step)
        
        current_path.remove(item_name)

    def calculate_ratio(self):
        if not self.selected_item or not self.entry_rate.get():
            return
        try:
            target_rate = float(self.entry_rate.get())
            production_chain = []
            visited = {}
            
            # Build the production chain
            self.build_production_chain(self.selected_item, target_rate, production_chain, visited, set())
            
            # Calculate totals
            self.render_output(production_chain, target_rate)
        except Exception as e:
            messagebox.showerror("Calc Error", str(e))
            print(traceback.format_exc())

    def render_output(self, steps, initial_rate):
        self.text_output.delete("1.0", tk.END)
        
        # Calculate totals
        total_cost = sum(s['cost'] for s in steps)
        total_pol = sum(s['pollution'] for s in steps)
        total_pwr = sum(s['power'] for s in steps) / 1000  # Convert to MW
        total_machines = sum(s['count'] for s in steps)

        # --- TOP HEADER TOTALS ---
        self.text_output.insert(tk.END, f"=== TOTAL PROJECT STATS ===\n")
        self.text_output.insert(tk.END, f"TOTAL POLLUTION: {round(total_pol, 2)} /h\n")
        self.text_output.insert(tk.END, f"TOTAL POWER DRAW: {round(total_pwr, 2)} MF\n")
        self.text_output.insert(tk.END, f"TOTAL MACHINES: {total_machines}\n")
        self.text_output.insert(tk.END, f"TOTAL COST: {total_cost:,}$\n")
        self.text_output.insert(tk.END, f"Goal: {initial_rate} {self.selected_item}/s | Route: {self.route_var.get().upper()}\n")
        self.text_output.insert(tk.END, "="*40 + "\n\n")

        # Display steps in logical order (raw materials first)
        # Sort by: extractors first, then processors
        def get_step_order(step):
            machine = step['machine_name'].lower()
            if 'drill' in machine:
                return 0
            elif 'pump' in machine:
                return 1
            elif 'quarry' in machine:
                return 2
            elif 'tree' in machine:
                return 3
            else:
                return 4
        
        sorted_steps = sorted(steps, key=get_step_order)
        
        for step in sorted_steps:
            # Format inputs string
            input_str = ""
            if step.get('inputs'):
                input_items = step['inputs']
                input_str = ", ".join([f"{round(i['rate'], 3)} {i['item']}/s" for i in input_items])
            
            self.text_output.insert(tk.END, f"--- {step['machine_name']} x{step['count']} ---\n")
            self.text_output.insert(tk.END, f"  Cost: {step['cost']:,}$ | Pol: {round(step['pollution'], 2)}/h\n")
            self.text_output.insert(tk.END, f"  Out: {round(step['output_rate'], 3)} {step['output_item']}/s\n")
            if input_str:
                self.text_output.insert(tk.END, f"  In: {input_str}\n")
            self.text_output.insert(tk.END, "\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = RatioCalculatorApp(root)
    root.mainloop()